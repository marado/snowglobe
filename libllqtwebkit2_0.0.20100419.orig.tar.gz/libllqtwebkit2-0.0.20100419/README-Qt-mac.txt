Build instructions can be found here:

https://wiki.secondlife.com/wiki/LLQtWebKit
